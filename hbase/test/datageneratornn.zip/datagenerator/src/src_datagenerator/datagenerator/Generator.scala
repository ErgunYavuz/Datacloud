package datagenerator

import java.util.Properties

trait Generator {
  
  def generate:Unit
}